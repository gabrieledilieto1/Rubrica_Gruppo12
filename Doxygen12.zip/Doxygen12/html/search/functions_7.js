var searchData=
[
  ['returnmail_0',['returnMail',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a7d7d9d5eaeab5bedfeaccc520cfe159b',1,'com::mycompany::rubrica_gruppo12::Email']]],
  ['returnnum_1',['returnNum',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html#a9b472e9e6aaea72d6bd52871bc95d59e',1,'com::mycompany::rubrica_gruppo12::NumTelefono']]],
  ['ricerca_2',['Ricerca',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a9bedb389cc9518348a5d0b6b46d37b46',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['rimuovicontatto_3',['rimuoviContatto',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#aa5ac2ff61cc4a4a52e533133284fda03',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['rubrica_4',['Rubrica',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#ab751f43677f298c7122f49ccfdea06a4',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['rubricaexception_5',['RubricaException',['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html#a4a37be9f11c0cedab1376b2a1e398fcb',1,'com.mycompany.exception.RubricaException.RubricaException()'],['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html#a3db8ddb24a66c0601fae69545114708d',1,'com.mycompany.exception.RubricaException.RubricaException(String msg)']]]
];
