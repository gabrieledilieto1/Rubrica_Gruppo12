var searchData=
[
  ['ricerca_0',['Ricerca',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a9460e532eded1f7d1e983f136d2b2cd7',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['rubrica_1',['Rubrica',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#ab751f43677f298c7122f49ccfdea06a4',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['rubricaexception_2',['RubricaException',['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html#a4a37be9f11c0cedab1376b2a1e398fcb',1,'com.mycompany.exception.RubricaException.RubricaException()'],['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html#a3db8ddb24a66c0601fae69545114708d',1,'com.mycompany.exception.RubricaException.RubricaException(String msg)']]]
];
