var searchData=
[
  ['numtelefono_0',['NumTelefono',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html#a7a3439634371e79caf8a75a5ffcf62a9',1,'com::mycompany::rubrica_gruppo12::NumTelefono']]]
];
