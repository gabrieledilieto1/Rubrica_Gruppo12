var searchData=
[
  ['12_0',['### Progetto di Ingegneria del Software - Gruppo 12',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
