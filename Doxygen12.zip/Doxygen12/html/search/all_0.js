var searchData=
[
  ['aggiungicontatto_0',['aggiungiContatto',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a16515ec0f7d225e79dfeb97f04b2e130',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['aggiungiemail_1',['aggiungiEmail',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a0980c688bf796cc736e0050b8a0cd422',1,'com::mycompany::rubrica_gruppo12::Email']]],
  ['aggiunginumtelefono_2',['aggiungiNumTelefono',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html#ac887a188a8cce042b0d4596e1e68a0dc',1,'com::mycompany::rubrica_gruppo12::NumTelefono']]],
  ['app_3',['App',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_app.html',1,'com::mycompany::rubrica_gruppo12']]],
  ['app_2ejava_4',['App.java',['../_app_8java.html',1,'']]]
];
