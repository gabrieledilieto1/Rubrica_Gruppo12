var searchData=
[
  ['nomeecognomemancanteexception_0',['NomeECognomeMancanteException',['../classcom_1_1mycompany_1_1exception_1_1_nome_e_cognome_mancante_exception.html',1,'com::mycompany::exception']]],
  ['numerotelefonononvalidoexception_1',['NumeroTelefonoNonValidoException',['../classcom_1_1mycompany_1_1exception_1_1_numero_telefono_non_valido_exception.html',1,'com::mycompany::exception']]],
  ['numtelefono_2',['NumTelefono',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html',1,'com::mycompany::rubrica_gruppo12']]]
];
