var searchData=
[
  ['getcognome_0',['getCognome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#ab18ed0c750b3b1aa6ec339003353c648',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['getcontatto_1',['getContatto',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a762dc2f7af6fca214c0f3b379e1b26df',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['getelenco_2',['getElenco',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#adbecd297d1fa71a070e8e1d87d9902a2',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['getfiltro_3',['getFiltro',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a6b51b55ce002bfa1999034edbc6c9a11',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['getmail_4',['getMail',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#aed7df3d403a774b75cf39675bc69473e',1,'com.mycompany.rubrica_gruppo12.Contatto.getMail()'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a944ecb94be8ddde14ac598d479f383ab',1,'com.mycompany.rubrica_gruppo12.Email.getMail()']]],
  ['getnome_5',['getNome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a1de6b1986a53f7c4dab6e4e1289823a8',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['getnumeri_6',['getNumeri',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#af4ceccb429b65d571823854e611535f2',1,'com.mycompany.rubrica_gruppo12.Contatto.getNumeri()'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html#a7f63e44dd3c215a6c328bd6ede6517f8',1,'com.mycompany.rubrica_gruppo12.NumTelefono.getNumeri()']]]
];
