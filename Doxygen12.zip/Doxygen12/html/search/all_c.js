var searchData=
[
  ['requirements_20engineering_20📃_0',['Requirements Engineering 📃',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['ricerca_1',['Ricerca',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a9460e532eded1f7d1e983f136d2b2cd7',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['rubrica_2',['Rubrica',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html',1,'com.mycompany.rubrica_gruppo12.Rubrica'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#ab751f43677f298c7122f49ccfdea06a4',1,'com.mycompany.rubrica_gruppo12.Rubrica.Rubrica()']]],
  ['rubrica_20_3aiphone_3a_3',['Rubrica :iphone:',['../md__r_e_a_d_m_e.html',1,'']]],
  ['rubricaexception_4',['RubricaException',['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html',1,'com.mycompany.exception.RubricaException'],['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html#a4a37be9f11c0cedab1376b2a1e398fcb',1,'com.mycompany.exception.RubricaException.RubricaException()'],['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html#a3db8ddb24a66c0601fae69545114708d',1,'com.mycompany.exception.RubricaException.RubricaException(String msg)']]]
];
