var searchData=
[
  ['tostring_0',['toString',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a0e4771b2353e2b369cb49cf562b82a76',1,'com.mycompany.rubrica_gruppo12.Contatto.toString()'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a5041f8928f11a2f8617e6cd78c007650',1,'com.mycompany.rubrica_gruppo12.Email.toString()'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html#acbccbfbaf1beb2d62c5c093b34257ab5',1,'com.mycompany.rubrica_gruppo12.NumTelefono.toString()'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a581422e8a812a9831fa1f97eaa83325c',1,'com.mycompany.rubrica_gruppo12.Rubrica.toString()']]]
];
