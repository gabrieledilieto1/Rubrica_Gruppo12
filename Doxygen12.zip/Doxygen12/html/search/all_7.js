var searchData=
[
  ['getcognome_0',['getCognome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#ab18ed0c750b3b1aa6ec339003353c648',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['getelenco_1',['getElenco',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#adbecd297d1fa71a070e8e1d87d9902a2',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['getmail_2',['getMail',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#aed7df3d403a774b75cf39675bc69473e',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['getnome_3',['getNome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a1de6b1986a53f7c4dab6e4e1289823a8',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['getnumeri_4',['getNumeri',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#af4ceccb429b65d571823854e611535f2',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['gruppo_2012_5',['### Progetto di Ingegneria del Software - Gruppo 12',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
