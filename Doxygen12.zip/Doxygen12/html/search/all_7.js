var searchData=
[
  ['modificaemail_0',['modificaEmail',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a4554f82de0248f4c016c44a471043963',1,'com::mycompany::rubrica_gruppo12::Email']]],
  ['modificanumtelefono_1',['modificaNumTelefono',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_num_telefono.html#ac8945726741de67fd3d04b76a9d0c0e2',1,'com::mycompany::rubrica_gruppo12::NumTelefono']]]
];
