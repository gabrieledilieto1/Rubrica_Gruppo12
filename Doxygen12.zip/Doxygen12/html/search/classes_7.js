var searchData=
[
  ['rubrica_0',['Rubrica',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html',1,'com::mycompany::rubrica_gruppo12']]],
  ['rubricaexception_1',['RubricaException',['../classcom_1_1mycompany_1_1exception_1_1_rubrica_exception.html',1,'com::mycompany::exception']]]
];
