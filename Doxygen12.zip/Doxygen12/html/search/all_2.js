var searchData=
[
  ['duplicatiexception_0',['DuplicatiException',['../classcom_1_1mycompany_1_1exception_1_1_duplicati_exception.html',1,'com.mycompany.exception.DuplicatiException'],['../classcom_1_1mycompany_1_1exception_1_1_duplicati_exception.html#ac2d34a01b6e14d7b2b1e26f450b0b0be',1,'com.mycompany.exception.DuplicatiException.DuplicatiException()'],['../classcom_1_1mycompany_1_1exception_1_1_duplicati_exception.html#a7446608b005eade9d704b09626a93f0e',1,'com.mycompany.exception.DuplicatiException.DuplicatiException(String msg)']]],
  ['duplicatiexception_2ejava_1',['DuplicatiException.java',['../_duplicati_exception_8java.html',1,'']]]
];
