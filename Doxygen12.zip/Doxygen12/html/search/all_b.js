var searchData=
[
  ['setcognome_0',['setCognome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a522a75385ffe862e2a1804e230c4a6d2',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['setmail_1',['setMail',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#adb881faa966aae6f2ebf6bc91602a53c',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['setnome_2',['setNome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a3f9bf45967f7e1ea34ea48206fd94fb6',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['setnumeri_3',['setNumeri',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a3f1176bd4c7a2d3e7f6ea1b26700c233',1,'com::mycompany::rubrica_gruppo12::Contatto']]]
];
