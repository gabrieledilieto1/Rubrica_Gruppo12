var searchData=
[
  ['primarycontroller_0',['PrimaryController',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_primary_controller.html',1,'com::mycompany::rubrica_gruppo12']]],
  ['progetto_20_3aflashlight_3a_1',['Descrizione del Progetto :flashlight:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['progetto_20di_20ingegneria_20del_20software_20gruppo_2012_2',['### Progetto di Ingegneria del Software - Gruppo 12',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]]
];
