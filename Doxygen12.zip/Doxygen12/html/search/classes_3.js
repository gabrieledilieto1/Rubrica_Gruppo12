var searchData=
[
  ['email_0',['Email',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html',1,'com::mycompany::rubrica_gruppo12']]],
  ['emailnonvalidaexception_1',['EmailNonValidaException',['../classcom_1_1mycompany_1_1exception_1_1_email_non_valida_exception.html',1,'com::mycompany::exception']]],
  ['emailtest_2',['EmailTest',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email_test.html',1,'com::mycompany::rubrica_gruppo12']]]
];
