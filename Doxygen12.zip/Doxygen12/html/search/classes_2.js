var searchData=
[
  ['duplicatiexception_0',['DuplicatiException',['../classcom_1_1mycompany_1_1exception_1_1_duplicati_exception.html',1,'com::mycompany::exception']]]
];
