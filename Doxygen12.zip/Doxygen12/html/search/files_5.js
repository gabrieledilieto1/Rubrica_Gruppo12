var searchData=
[
  ['nomeecognomemancanteexception_2ejava_0',['NomeECognomeMancanteException.java',['../_nome_e_cognome_mancante_exception_8java.html',1,'']]],
  ['numerotelefonononvalidoexception_2ejava_1',['NumeroTelefonoNonValidoException.java',['../_numero_telefono_non_valido_exception_8java.html',1,'']]],
  ['numtelefono_2ejava_2',['NumTelefono.java',['../_num_telefono_8java.html',1,'']]]
];
