var searchData=
[
  ['del_20progetto_20_3aflashlight_3a_0',['Descrizione del Progetto :flashlight:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['del_20software_20gruppo_2012_1',['### Progetto di Ingegneria del Software - Gruppo 12',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['descrizione_20del_20progetto_20_3aflashlight_3a_2',['Descrizione del Progetto :flashlight:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['design_20📲_3',['Design 📲',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['di_20ingegneria_20del_20software_20gruppo_2012_4',['### Progetto di Ingegneria del Software - Gruppo 12',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['duplicatiexception_5',['DuplicatiException',['../classcom_1_1mycompany_1_1exception_1_1_duplicati_exception.html',1,'com::mycompany::exception']]]
];
