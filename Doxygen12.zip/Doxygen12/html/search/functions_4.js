var searchData=
[
  ['formatofilenonvalidoexception_0',['FormatoFileNonValidoException',['../classcom_1_1mycompany_1_1exception_1_1_formato_file_non_valido_exception.html#aa9c4ba32ed1dcc5e6963f07e03220fda',1,'com.mycompany.exception.FormatoFileNonValidoException.FormatoFileNonValidoException()'],['../classcom_1_1mycompany_1_1exception_1_1_formato_file_non_valido_exception.html#a2eeda44d1de68c31c8ccfc5c5017c620',1,'com.mycompany.exception.FormatoFileNonValidoException.FormatoFileNonValidoException(String message)']]]
];
