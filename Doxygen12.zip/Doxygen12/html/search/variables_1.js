var searchData=
[
  ['nome_0',['nome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a8cf8a5b140596284057dda0973b97755',1,'com::mycompany::rubrica_gruppo12::Contatto']]]
];
