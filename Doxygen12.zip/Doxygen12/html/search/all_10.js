var searchData=
[
  ['📲_0',['Design 📲',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
