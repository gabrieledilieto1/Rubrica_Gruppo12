var searchData=
[
  ['secondarycontroller_0',['SecondaryController',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_secondary_controller.html',1,'com::mycompany::rubrica_gruppo12']]]
];
