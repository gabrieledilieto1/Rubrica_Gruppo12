var searchData=
[
  ['importa_0',['importa',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a336339d5fa079b602b9f3738dc5bf5de',1,'com::mycompany::rubrica_gruppo12::Rubrica']]],
  ['ingegneria_20del_20software_20gruppo_2012_1',['### Progetto di Ingegneria del Software - Gruppo 12',['../md__r_e_a_d_m_e.html#autotoc_md1',1,'']]],
  ['initialize_2',['initialize',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_primary_controller.html#adab20ffe27e925d9c20b41b5cfdef97f',1,'com.mycompany.rubrica_gruppo12.PrimaryController.initialize()'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_secondary_controller.html#a2241a2f75bc5817be8b6bf464781d63e',1,'com.mycompany.rubrica_gruppo12.SecondaryController.initialize()']]]
];
