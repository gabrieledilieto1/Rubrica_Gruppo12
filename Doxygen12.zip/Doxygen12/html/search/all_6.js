var searchData=
[
  ['importa_0',['importa',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a336339d5fa079b602b9f3738dc5bf5de',1,'com::mycompany::rubrica_gruppo12::Rubrica']]]
];
