var searchData=
[
  ['_3aiphone_3a_0',['Rubrica :iphone:',['../md__r_e_a_d_m_e.html',1,'']]]
];
