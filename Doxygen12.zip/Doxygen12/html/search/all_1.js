var searchData=
[
  ['compare_0',['compare',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto_compare.html#aff7fb2cfeb2a4d3132c517723a842b63',1,'com::mycompany::rubrica_gruppo12::ContattoCompare']]],
  ['contatto_1',['Contatto',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html',1,'com.mycompany.rubrica_gruppo12.Contatto'],['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a8a9d84bcae45b0e57090013e6a875ae3',1,'com.mycompany.rubrica_gruppo12.Contatto.Contatto()']]],
  ['contattocompare_2',['ContattoCompare',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto_compare.html',1,'com::mycompany::rubrica_gruppo12']]],
  ['contattotest_3',['ContattoTest',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto_test.html',1,'com::mycompany::rubrica_gruppo12']]]
];
