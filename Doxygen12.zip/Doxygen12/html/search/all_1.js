var searchData=
[
  ['_3aelevator_3a_0',['Componenti :elevator:',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['_3aflashlight_3a_1',['Descrizione del Progetto :flashlight:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['_3aiphone_3a_2',['Rubrica :iphone:',['../md__r_e_a_d_m_e.html',1,'']]]
];
