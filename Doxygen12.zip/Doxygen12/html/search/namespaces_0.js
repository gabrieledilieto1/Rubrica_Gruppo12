var searchData=
[
  ['com_3a_3amycompany_3a_3aexception_0',['exception',['../namespacecom_1_1mycompany_1_1exception.html',1,'com::mycompany']]],
  ['com_3a_3amycompany_3a_3arubrica_5fgruppo12_1',['rubrica_gruppo12',['../namespacecom_1_1mycompany_1_1rubrica__gruppo12.html',1,'com::mycompany']]]
];
