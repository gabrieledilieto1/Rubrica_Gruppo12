var searchData=
[
  ['cognome_0',['cognome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#af6129f1fb1296b75efe33dcb3e3df973',1,'com::mycompany::rubrica_gruppo12::Contatto']]]
];
