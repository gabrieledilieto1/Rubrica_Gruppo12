var searchData=
[
  ['email_0',['Email',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a7189fcab5d5101cecfb823eac18dad41',1,'com::mycompany::rubrica_gruppo12::Email']]],
  ['esporta_1',['esporta',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a994194484d90cc89a6e08c94493b3c3b',1,'com::mycompany::rubrica_gruppo12::Rubrica']]]
];
