var searchData=
[
  ['📃_0',['Requirements Engineering 📃',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
