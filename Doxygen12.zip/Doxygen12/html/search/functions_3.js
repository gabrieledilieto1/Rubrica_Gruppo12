var searchData=
[
  ['email_0',['Email',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_email.html#a7189fcab5d5101cecfb823eac18dad41',1,'com::mycompany::rubrica_gruppo12::Email']]],
  ['emailnonvalidaexception_1',['EmailNonValidaException',['../classcom_1_1mycompany_1_1exception_1_1_email_non_valida_exception.html#a789442cf503c34bfb5a4d0cd87dc0100',1,'com.mycompany.exception.EmailNonValidaException.EmailNonValidaException()'],['../classcom_1_1mycompany_1_1exception_1_1_email_non_valida_exception.html#a5af181d8e931d52d8b57966c5abcaec6',1,'com.mycompany.exception.EmailNonValidaException.EmailNonValidaException(String message)']]],
  ['esporta_2',['esporta',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_rubrica.html#a994194484d90cc89a6e08c94493b3c3b',1,'com::mycompany::rubrica_gruppo12::Rubrica']]]
];
