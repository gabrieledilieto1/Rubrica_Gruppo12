var searchData=
[
  ['primarycontroller_0',['PrimaryController',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_primary_controller.html',1,'com::mycompany::rubrica_gruppo12']]],
  ['primarycontroller_2ejava_1',['PrimaryController.java',['../_primary_controller_8java.html',1,'']]]
];
