var searchData=
[
  ['setcognome_0',['setCognome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a522a75385ffe862e2a1804e230c4a6d2',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['setnome_1',['setNome',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_contatto.html#a3f9bf45967f7e1ea34ea48206fd94fb6',1,'com::mycompany::rubrica_gruppo12::Contatto']]],
  ['start_2',['start',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_app.html#af57de1fbaf076de8c0314448a51e7ac6',1,'com::mycompany::rubrica_gruppo12::App']]]
];
