var indexSectionsWithContent =
{
  0: "acdefgimnprst",
  1: "acdefnprs",
  2: "c",
  3: "acdefnprs",
  4: "acdefgimnrst",
  5: "cn"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables"
};

