var searchData=
[
  ['app_0',['App',['../classcom_1_1mycompany_1_1rubrica__gruppo12_1_1_app.html',1,'com::mycompany::rubrica_gruppo12']]]
];
