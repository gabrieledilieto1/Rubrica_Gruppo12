/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rubricagruppo12;
import java.time.LocalDate;
import java.util.Objects;
import java.util.TreeSet;
import java.util.Set;
/**
 *
 * @author lucad_es3t3f8
 */
public class Rubrica {
    TreeSet <Contatto> elenco = new TreeSet<>();
    
     public void aggiungi(Contatto c) {
     elenco.add(c); 
    }   
     
       @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        System.out.println("l'elenco è formato da: \n");
        for (Contatto c : elenco){
            sb.append(c);
            sb.append("\n *** \n");
        }
            return sb.toString();
    } 
    
    
    /* Da inserire il metodo con cui il tree set ordina*/
}
